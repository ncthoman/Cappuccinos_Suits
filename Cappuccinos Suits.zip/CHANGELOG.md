# Version 1.1.3
Added Lebron James
Changelog format fix

# Version 1.1.2
Added changelog functionality
Updated Pack for Skeletor

# Version 1.1.1
Added Heisenberg suit
Updated details listed

# Version 1.1.0
First Update
Added Skeletor suit