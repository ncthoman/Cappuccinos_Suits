# Cappuccinos Suits
Adds more suits using MoreSuits by x753

Current Suits added: 
- Skeletor
- Heisenberg
- Lebron

